﻿/*
 Jeremy Gurzynski
 CSC202
 jgurzynski85952@uat.edu
 Week 3 MoonBase Alpha II Assignment
 */

//These lines are used for various functionalities of C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Name of our file
namespace Moonbase
{
    //Declares our Moonbase that inherits from form
    public partial class Moonbase : Form
    {
        //Array to hold different locations
        private Rooms[] locations;
        //private int created for tracking locations
        private int currentLoc;  


        //Constructor for our form
        public Moonbase()
        {
            //Initializes control objects, properties, and adds to proper control collections.
            InitializeComponent();
            //initializes array for locations
            InitializeLocations();
        }

        //created a class for rooms for better control
        public class Rooms
        {
            //string for background patch to get and set the image, get set example is location[1].backgroundPath
            public string backgroundPath { get; set; }
            //string for room name to get and set the name
            public string roomName { get; set; }
            //string for room description to get and set the description
            public string roomDesc { get; set; }
        }

        //Array function with data for each room to display
        private void InitializeLocations()
        {
            //The array for our locations
            locations = new Rooms[5]
            {
                // This is 0, central control
                new Rooms
                {
                    //variable for background path of image
                    backgroundPath = "ControlRoom.jpg",
                    //varibale for room name
                    roomName = "Central Control Room",
                     //variable for room description
                    roomDesc = "This is the main control center of Cosmos Command."
                },
                // This is 1, operations
                new Rooms
                {
                    //variable for background path of image
                    backgroundPath = "opsroom.jpg",
                    //varibale for room name
                    roomName = "Operations Room",
                     //variable for room description
                    roomDesc = "Operations and management are handled in this room."
                },
                // This is 2, security
                new Rooms
                {
                    //variable for background path of image
                    backgroundPath = "secroom.jpg",
                    //varibale for room name
                    roomName = "Security Room",
                    //variable for room description
                    roomDesc = "Security monitoring and access control are managed here."
                },
                // This is 3, communications
                new Rooms
                {
                    //variable for background path of image
                    backgroundPath = "comroom.jpg",
                    //varibale for room name
                    roomName = "Communications Room",
                    //variable for room description
                    roomDesc = "Monitors all internal and external messages systems. ",
                },
                // This is 4, engineering
                new Rooms
                {
                    //variable for background path of image
                    backgroundPath = "engRoom.jpg",
                    //varibale for room name
                    roomName = "Engineering Room",
                    //variable for room description
                    roomDesc = "Advanced engineering and maintenance activities are conducted here."
                }
            };
        }
        //Function for displaying the images from the arrays
        private void ShowLocation(int index)
        {
            //background image change utilizing the arrays data
            BackgroundImage = Image.FromFile(locations[index].backgroundPath);
        }



        //Log File Function with the location string variable
        private void logLocation(string location) 
        {
            //This is for collecting the current date and time with the location
            string logMessage = $"{DateTime.Now}: Moved to {location}";
            //This is where the information will be logged
            string logFile = "locationLog.txt"; 
            //StreamWriter is used for writing to the log files
            using (StreamWriter lw = File.AppendText(logFile)) 
            {
                //Function for writing the lines
                lw.WriteLine(logMessage);
            }


        }
        //Function for each area
        //function for central control room, 0
        private void centralControlRoom() 
        {
            //Message box will display with the location with assigned number in array function, $ symbol for calling the string
            MessageBox.Show($"Going back to: {locations[0].roomName} \n{locations[0].roomDesc}");
            //Call the location with the assigned number from our array
            currentLoc = 0;
            //Call the show locations function with current locations variable
            ShowLocation(currentLoc);

            //if created to show and hide necessary data
            if (currentLoc == 0)
            {
                // Next few Lines are for hiding and showing the groupboxes of room name, description and the buttons.
                GBcenconroom.Show();
                GBbackbtn.Hide();
                GBpernav.Show();
                GBopsroom.Hide();
                GBcomroom.Hide();
                GBeng.Hide();
                GBsecroom.Hide();
            }
            //Call log location function with the name of the room for logging
            logLocation("Central Control Room");

        }
        //Function for Operations, 1
        private void operationsRoom() 
        {
            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {locations[1].roomName} \n{locations[1].roomDesc}");
            //sets the current location
            currentLoc = 1;
            //Call the show locations function with current locations variable to change image
            ShowLocation(currentLoc);
            
            //if created to show and hide necessary data
            if (currentLoc == 1)
            {
                //These lines are for hiding and showing the groupboxes of room name, description and the buttons.
                GBopsroom.Show();
                GBcenconroom.Hide();
                GBbackbtn.Show();
                GBpernav.Hide();
                GBeng.Hide();
                GBcomroom.Hide();
                GBsecroom.Hide();
            }
            //Call log location function with the name of the room for logging
            logLocation("Operations Room");
        }
        //Function for Security, 2
        private void securityRoom() 
        {
            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going back to: {locations[2].roomName} \n{locations[2].roomDesc}");
            //sets the current location
            currentLoc = 2;
            //Call the show locations function with current locations variable to display the image
            ShowLocation(currentLoc);
            //if created to show and hide necessary data
            if (currentLoc == 2)
            {
                //These lines are for hiding and showing the groupboxes of room name, description and the buttons.
                GBcenconroom.Hide();
                GBcomroom.Hide();
                GBbackbtn.Show();
                GBpernav.Hide();
                GBopsroom.Hide();
                GBeng.Hide();
                GBsecroom.Show();
            }
            //Call log location function with the name of the room for logging
            logLocation("Security Room");
        }
        //Function for Communications
        private void communicationsRoom()
        {
            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {locations[3].roomName} \n{locations[3].roomDesc}");
            //Sets the current location
            currentLoc = 3;
            //Changes background image depending on the current location
            ShowLocation(currentLoc);
            //if created to show and hide necessary data
            if (currentLoc == 3)
            {
                //These lines are for hiding and showing the groupboxes of room name, description and the buttons.
                GBcenconroom.Hide();
                GBcomroom.Show();
                GBbackbtn.Show();
                GBpernav.Hide();
                GBeng.Hide();
                GBopsroom.Hide();
                GBsecroom.Hide();
            }
        
            //Call log location function with the name of the room for logging
            logLocation("Communications Room");
        }
        //Function for Engineering
        private void engineeringRoom()
        {
            //Message box will display location name and short description from the array data
            MessageBox.Show($"Going to: {locations[4].roomName} \n{locations[4].roomDesc}");
            //set the current location
            currentLoc = 4;
            //function for changing background image
            ShowLocation(currentLoc);
            //if created to show and hide necessary data
            if (currentLoc == 4)
            {
                //These lines are for hiding and showing the groupboxes of room name, description and the buttons.
                GBcenconroom.Hide();
                GBcomroom.Hide();
                GBbackbtn.Show();
                GBpernav.Hide();
                GBopsroom.Hide();
                GBeng.Show();
                GBsecroom.Hide();
            }
            //Stored the hide and shows in an if statement

            //Call log location function with the name of the room for logging
            logLocation("Engineering Room");
        }
        //And finally the buttons that activate each function
        //Function called when button is pressed.
        private void BTNops_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            operationsRoom();
            
        }
        //Function called when button is pressed.
        private void BTNeng_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            engineeringRoom();
            
        }
        //Function called when button is pressed.
        private void BTNres_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            securityRoom();
        }
        //Function called when button is pressed.
        private void BTNcoms_Click(object sender, EventArgs e)
        {
   
            //call function for this area
            communicationsRoom();
        }
        //Function called when button is clicked
        private void BTNcencon_Click(object sender, EventArgs e)
        {

            //Calling function for the area
            centralControlRoom();
        }
    }
}
